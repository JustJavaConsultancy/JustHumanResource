package com.justjava.humanresource.payroll.service.impl;


import com.justjava.humanresource.core.enums.PayrollRunStatus;
import com.justjava.humanresource.hr.repository.EmployeeRepository;
import com.justjava.humanresource.payroll.entity.PaySlip;
import com.justjava.humanresource.payroll.entity.PayrollPeriod;
import com.justjava.humanresource.payroll.enums.PayrollPeriodStatus;
import com.justjava.humanresource.payroll.repositories.PaySlipRepository;
import com.justjava.humanresource.payroll.repositories.PayrollPeriodRepository;
import com.justjava.humanresource.payroll.repositories.PayrollRunRepository;
import com.justjava.humanresource.payroll.service.PayrollPeriodService;
import com.justjava.humanresource.core.enums.RecordStatus;
import lombok.RequiredArgsConstructor;
import org.flowable.engine.RuntimeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.justjava.humanresource.hr.entity.Employee;
import java.util.stream.Collectors;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PayrollPeriodServiceImpl implements PayrollPeriodService {

    private final PayrollPeriodRepository payrollPeriodRepository;
    private final PayrollPeriodRepository repository;
    private final PayrollRunRepository payrollRunRepository;
    private final RuntimeService runtimeService;
    private final PaySlipRepository paySlipRepository;
    private final EmployeeRepository employeeRepository;

    /* ============================================================
       INITIALIZATION
       ============================================================ */

    @Override
    @Transactional
    public PayrollPeriod openInitialPeriod(
            Long companyId,
            LocalDate periodStart,
            LocalDate periodEnd
    ) {

        if (periodStart == null || periodEnd == null) {
            throw new IllegalArgumentException("Period start/end cannot be null.");
        }

        if (periodEnd.isBefore(periodStart)) {
            throw new IllegalArgumentException("Period end cannot be before start.");
        }

        if (repository.existsByCompanyIdAndStatus(
                companyId,
                PayrollPeriodStatus.OPEN)) {

            throw new IllegalStateException(
                    "Company already has an OPEN payroll period.");
        }

        PayrollPeriod period = new PayrollPeriod();
        period.setCompanyId(companyId);
        period.setPeriodStart(periodStart);
        period.setPeriodEnd(periodEnd);
        period.setStatus(PayrollPeriodStatus.OPEN);

        return repository.save(period);
    }

    /* ============================================================
       CLOSE & OPEN NEXT
       ============================================================ */

    @Override
    @Transactional
    public void closeAndOpenNext(Long companyId) {

        // ---------------------------------------------------------
        // 1. Get Current OPEN Period
        // ---------------------------------------------------------

        PayrollPeriod current = getOpenPeriod(companyId);

        // ---------------------------------------------------------
        // 2. Validate All Runs Are POSTED
        // ---------------------------------------------------------

        long incomplete =
                payrollRunRepository
                        .countLatestByCompanyAndPayrollDateBetweenAndStatusNot(
                                companyId,
                                current.getPeriodStart(),
                                current.getPeriodEnd(),
                                PayrollRunStatus.POSTED
                        );

        if (incomplete > 0) {
            throw new IllegalStateException(
                    "Cannot close period. Some payroll runs are not POSTED."
            );
        }

        // ---------------------------------------------------------
        // 3. Close Current Period
        // ---------------------------------------------------------

        current.setStatus(PayrollPeriodStatus.CLOSED);
        repository.save(current);

        // ---------------------------------------------------------
        // 4. Compute Next Period Range
        // ---------------------------------------------------------

        long cycleDays =
                current.getPeriodEnd().toEpochDay()
                        - current.getPeriodStart().toEpochDay()
                        + 1;

        LocalDate nextStart = current.getPeriodEnd().plusDays(1);
        LocalDate nextEnd = nextStart.plusDays(cycleDays - 1);

        PayrollPeriod next = new PayrollPeriod();
        next.setCompanyId(companyId);
        next.setPeriodStart(nextStart);
        next.setPeriodEnd(nextEnd);
        next.setStatus(PayrollPeriodStatus.OPEN);

        repository.save(next);

        // ---------------------------------------------------------
        // 5. Ensure New Period Has No Existing Runs (Idempotency Guard)
        // ---------------------------------------------------------

        long existingNewPeriodRuns =
                payrollRunRepository.countByEmployee_Department_Company_IdAndPayrollDateBetween(
                        companyId,
                        nextStart,
                        nextEnd
                );

        if (existingNewPeriodRuns > 0) {
            throw new IllegalStateException(
                    "Payroll runs already exist for new period. Aborting carry-forward."
            );
        }

        // ---------------------------------------------------------
        // 6. Carry Forward (Flowable Driven)
        // ---------------------------------------------------------

        runtimeService.startProcessInstanceByKey(
                "payrollCarryForwardProcess",
                Map.of(
                        "companyId", companyId,
                        "oldPeriodStart", current.getPeriodStart(),
                        "oldPeriodEnd", current.getPeriodEnd(),
                        "newPeriodStart", nextStart,
                        "newPeriodEnd", nextEnd
                )
        );
    }
    /* ============================================================
       GET OPEN PERIOD
       ============================================================ */

    @Override
    public PayrollPeriod getOpenPeriod(Long companyId) {

        return repository
                .findByCompanyIdAndStatus(
                        companyId,
                        PayrollPeriodStatus.OPEN
                ).orElse(null);
    }

    /* ============================================================
       VALIDATION
       ============================================================ */

    @Override
    public void validatePayrollDate(
            Long companyId,
            LocalDate payrollDate
    ) {

        PayrollPeriod open = getOpenPeriod(companyId);

        if (payrollDate.isBefore(open.getPeriodStart())
                || payrollDate.isAfter(open.getPeriodEnd())) {

            throw new IllegalStateException(
                    "Payroll date " + payrollDate +
                            " is outside the OPEN payroll period."
            );
        }
    }

    @Override
    public boolean isPayrollDateInOpenPeriod(
            Long companyId,
            LocalDate payrollDate
    ) {

        return repository
                .findByCompanyIdAndPeriodStartLessThanEqualAndPeriodEndGreaterThanEqual(
                        companyId,
                        payrollDate,
                        payrollDate
                )
                .map(period -> period.getStatus() == PayrollPeriodStatus.OPEN)
                .orElse(false);
    }

    @Override
    public PayrollPeriodStatus getPeriodStatusForDate(
            Long companyId,
            LocalDate payrollDate
    ) {

        return repository
                .findByCompanyIdAndPeriodStartLessThanEqualAndPeriodEndGreaterThanEqual(
                        companyId,
                        payrollDate,
                        payrollDate
                )
                .map(PayrollPeriod::getStatus)
                .orElse(null);
    }
    @Override
    public PayrollPeriodStatus getCurrentPeriodStatus(Long companyId) {
        PayrollPeriod current =
                payrollPeriodRepository
                        .findByCompanyIdAndStatusIn(
                                companyId,
                                List.of(
                                        PayrollPeriodStatus.OPEN,
                                        PayrollPeriodStatus.LOCKED
                                )
                        )
                        .orElse(null);
        PayrollPeriodStatus status = current != null ? current.getStatus() : null;
        return status;
    }
    @Override
    public PayrollPeriod getCurrentPeriod(Long companyId) {
        PayrollPeriod current =
                payrollPeriodRepository
                        .findByCompanyIdAndStatusIn(
                                companyId,
                                List.of(
                                        PayrollPeriodStatus.OPEN,
                                        PayrollPeriodStatus.LOCKED
                                )
                        )
                        .orElse(null);

        return current;
    }
    /* ============================================================
       FLOWABLE APPROVAL
       ============================================================ */


    @Override
    @Transactional
    public void initiatePeriodCloseApproval(Long companyId) {

        PayrollPeriod open = getOpenPeriod(companyId);

        if (open == null) {
            throw new IllegalStateException("No open payroll period found.");
        }

        List<Employee> missingDetails = employeeRepository.findEmployeesMissingBankDetails(companyId);

        if (!missingDetails.isEmpty()) {

            String names = missingDetails.stream()
                    .map(emp -> emp.getFirstName() + " " + emp.getLastName())
                    .distinct()
                    .collect(Collectors.joining(", "));

            throw new IllegalStateException(
                    "BLOCKING ERROR: Period cannot be locked. " + missingDetails.size() +
                            " employee(s) are missing bank details: [" + names + "]."
            );
        }

        runtimeService.startProcessInstanceByKey(
                "payrollPeriodCloseProcess",
                Map.of(
                        "companyId", open.getCompanyId(),
                        "periodId", open.getId(),
                        "periodStart", open.getPeriodStart(),
                        "periodEnd", open.getPeriodEnd()
                )
        );
    }


    @Override
    public PayrollPeriod findById(Long id) {
        return repository.findById(id).orElse(null);
    }
}
