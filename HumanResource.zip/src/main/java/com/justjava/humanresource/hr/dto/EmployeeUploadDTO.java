package com.justjava.humanresource.hr.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class EmployeeUploadDTO {

    private String firstName;
    private String secondName;
    private String email;
    private String grade;
    private BigDecimal gross;

    // Optional bank details (from CSV columns 6–8)
    private String accountName;
    private String bankName;
    private String accountNumber;
}