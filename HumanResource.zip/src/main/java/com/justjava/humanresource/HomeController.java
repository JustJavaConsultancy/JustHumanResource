package com.justjava.humanresource;

import com.justjava.humanresource.core.config.AuthenticationManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {
    @Autowired
    AuthenticationManager authenticationManager;

    @GetMapping("/")
    public String home(Model model) {

        System.out.println(authenticationManager.getAllAttributes()); // hypothetical method
        System.out.println(" Is Employee ===" + authenticationManager.isEmployee());

        if (authenticationManager.isEmployee()) {
            return "redirect:/employee/dashboard";
        } else if (authenticationManager.isFinancialOfficer()) {
            return "redirect:/finance/dashboard";
        } else if (authenticationManager.isAdmin()) {
            return "redirect:/admin/users";
        } else if (authenticationManager.isHumanResource()) {
            return "redirect:/departments";
        }

        // Default view if no role matches
        model.addAttribute("title", "Welcome to JustJava HR");
        model.addAttribute("subTitle", "Streamline your HR processes with ease");

        return "index"; // <-- IMPORTANT: return a view name
    }

}
